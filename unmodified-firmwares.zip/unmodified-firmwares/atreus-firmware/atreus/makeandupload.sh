make upload KEYMAP=qwerty_bill USB=/dev/cu.usbmodem14141
