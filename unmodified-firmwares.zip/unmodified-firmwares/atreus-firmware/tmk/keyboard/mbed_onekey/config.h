#ifndef CONFIG_H
#define CONFIG_H

#define MATRIX_ROWS 1
#define MATRIX_COLS 1

#endif
