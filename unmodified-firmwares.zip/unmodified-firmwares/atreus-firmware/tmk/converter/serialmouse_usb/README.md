Serial mouse converter
======================
See https://github.com/tmk/tmk_keyboard/pull/131


Supported protocols
-------------------
### Microsoft
Not tested.

### Mousesystems
