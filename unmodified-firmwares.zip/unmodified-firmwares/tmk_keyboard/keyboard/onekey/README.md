Onekey
======
Just one key keyboard for example. It sends 'a' key if pins PB0 and PB1 are short-circuited.

https://github.com/tmk/tmk_keyboard/issues/56
